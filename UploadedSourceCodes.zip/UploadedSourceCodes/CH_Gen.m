

function hh = CH_Gen(Chmod, L)

switch Chmod
    case 'Expon+Relaxed'
        eta   = 0.01*randi([1,50],1);
        ch_ev = sqrt(exp(-eta*(0:L-1))).';
        hh  = sqrt(0.5)*(randn(L,1) + 1j*randn(L,1));
        hh = hh.*ch_ev;
        hh = hh./norm(hh);
    case 'AWGN+Relaxed'
        hh = 1;
    case 'Expon+nonRelaxed'
        eta   = 1/L;
        ch_ev = sqrt(exp(-eta*(0:L-1))).'; 
        hh  = sqrt(0.5)*(randn(L,1) + 1j*randn(L,1));
        hh = hh.*ch_ev;
        hh = hh./norm(hh);
    case 'TDL-A+nonRelaxed'
        ch_ev = cell2mat(struct2cell(load('pathAver_Gains.mat')));
        L = 23;
        hh  = (sqrt(0.5)*complex(randn(L,1), randn(L,1)));
        hh = hh.*ch_ev;
        hh = hh./norm(hh);
    case 'TDL-B+nonRelaxed'
        ch_ev = cell2mat(struct2cell(load('pathAver_Gains.mat')));
        L = 23;
        hh  = (sqrt(0.5)*complex(randn(L,1), randn(L,1)));
        hh = hh.*ch_ev;
        hh = hh./norm(hh);
    case 'TDL-C+nonRelaxed'
        ch_ev = cell2mat(struct2cell(load('pathAver_Gains.mat')));
        L = 24;
        hh  = (sqrt(0.5)*complex(randn(L,1), randn(L,1)));
        hh = hh.*ch_ev;
        hh = hh./norm(hh);
end