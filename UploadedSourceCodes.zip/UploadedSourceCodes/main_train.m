clear all
close all
clc
% ========================================================
% % ======================= 2022.02.15====================
% % =====================Shuhai Tang======================
% % % 
% % % 
Nframe = 1.25e5;             % Size of data set
Lc   = 32;                   % Length of cyclic prefix
N    = 128;                  % Number of subcarriers (number of IDFT points)
Nc   = N;                    % Length of training sequence
Nu   = N+Lc;                 % Length of Complete OFDM symbol
SNR  = 1:5:16;               % Equivalent SNR
Pn_i = randi([1,length(SNR)],Nframe,1);
SNRs = SNR(Pn_i);
SNRs = SNRs(randperm(Nframe,Nframe)); %Mixed training SNRs
L    = 28;                   % For the relaxed constriction of propagation delay
save('Net_para',"Lc","Nc","L");
tmax= N-1;                   % Maximum timing offset
Nw  = N+Nu;                  % Length of intercepted receips

% ========================================================
Label  = zeros(1,Nframe);    % Label initialization 

chmod  = 'Expon';            % CH model selection
Cofg = [chmod,'+','Relaxed'];   % wether adopting relaxed constriction

tdl = nrTDLChannel;                 % Configure
if sum(chmod=='TDL-A')==length(chmod) || sum(chmod=='TDL-B')==length(chmod) || sum(chmod=='TDL-C')==length(chmod) 
    tdl.DelayProfile = chmod;       % acess PDP 
    pathAver_GainsdB = info(tdl).AveragePathGains;     % obtain PDP in dB
    pathAver_Gains = 10.^(0.05*pathAver_GainsdB).';    % obtain PDP
    save('pathAver_Gains','pathAver_Gains');
end
tic
for jj = 1:Nframe

    Txdata = TxdataGen(N,Lc,Nc);   % Transmission        
     
    hh     = CH_Gen(Cofg, L);      % CH configuration

    tau    = randi([0,tmax],1);    % randomly timing offset

    cfo    = 0.000000463;          % Normalized CFO
    A      = exp(1j*2*pi*cfo*(0:length(Txdata)-1)).';   % Multiplicative interference

    y      = awgn(PChannel(hh,Txdata,Nw,tau,A), SNRs(jj), 'measured');  %  Received
    
    temp0  = reshape([real(y),imag(y)].', [], 1);  
    Datatrain(:,:,jj) = temp0; 
    Label (jj) = tau;

end
toc
save('train_data','Datatrain');   %,'xm_train','xm_valid');
save('train_label','Label');
clear all

