
.m files:
1. CH_Gen: generating channel models
2. main_test: genererating test data
3. main_train: generating train data
4. TChannel:  generating the received signal
5. TxdataGen: generating the trainsmitted signal
6. Zadoff_Chu: generating the training sequence

.py files 
1. OfflineTraining:  Training network
2. OnlineDeployment: Testing network

.png file
1. FCNN-based TS network: depicting network architecture

.txt files
1. package: python environments
2. Readme:  brief descrption of the upload files