

close all
clear all
clc

SNR  = 0: 2: 12;

Pr   = cell2mat(struct2cell(load()));

figure
axes('LineWidth',1, 'box', 'on', 'FontSize', 16, 'YScale', 'log');hold on
set(gcf,'Position',[200 50 800 600]);set(gca,'color','none');
semilogy(SNR, Pr, '-or','LineWidth',2,'MarkerSize',8); hold on

xlabel('SNR (dB)','FontSize', 15);
ylabel('Error probability of TS (P_{{\ite},TS})','FontSize', 15);
axis on;