function Out = PChannel(h,x,Nw, tau,CFO)

y = 0;
for kk = 1:length(h)
   y = y + h(kk)*circshift(x, kk-1); 
end
temp1 = circshift(CFO.*y, tau);
Out = temp1(1:Nw);