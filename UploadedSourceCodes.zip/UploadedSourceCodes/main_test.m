clear all
close all
clc
% ========================================================
% % ======================= 2022.02.15====================
% % =====================Shuhai Tang======================
% % % 
% % % 
Nframe = 5e4;               % Size of testing Set
Lc  = 32;                   % Length of cyclic prefix
N   = 128;                  % Number of subcarriers (number of IDFT points)
Nc  = N;                    % Length of training sequence
Nu  = N+Lc;                 % Length of Complete OFDM symbol
SNR = 0:2:12;               % Equivalent SNR
Pn  = 10.^(-0.1*SNR);       % CSCG noise
L   = 23;                   % Test multi-path number
save('test_para',"L","Lc");
tmax= N-1;                  % Maximum timing offset
Nw  = N+Nu;                 % Length of intercepted receips

% ========================================================
Label  = zeros(1,Nframe);   % Label initialization 

chmod  = 'Expon';           % CH model selection
Cofg = [chmod,'+','nonRelaxed'];   % wether adopting relaxed constriction

tdl = nrTDLChannel;                 % Configure
switch chmod
    case 'TDL-A'
    tdl.DelayProfile = chmod;       % acess PDP 
    pathAver_GainsdB = info(tdl).AveragePathGains;  % obtain PDP in dB
    pathAver_Gains = 10.^(0.05*pathAver_GainsdB).';    % obtain PDP
    save('pathAver_Gains','pathAver_Gains');
    case 'TDL-B'
    tdl.DelayProfile = chmod;       % acess PDP 
    pathAver_GainsdB = info(tdl).AveragePathGains;  % obtain PDP in dB
    pathAver_Gains = 10.^(0.05*pathAver_GainsdB).';    % obtain PDP
    save('pathAver_Gains','pathAver_Gains');
    case 'TDL-C'
    tdl.DelayProfile = chmod;       % acess PDP 
    pathAver_GainsdB = info(tdl).AveragePathGains;  % obtain PDP in dB
    pathAver_Gains = 10.^(0.05*pathAver_GainsdB).';    % obtain PDP
    save('pathAver_Gains','pathAver_Gains');
end

for ii = 1: length(SNR)
tic
for jj = 1:Nframe

    Txdata = TxdataGen(N,Lc,Nc);   % Transmission        
    
    hh     = CH_Gen(Cofg, L);   % CH configuration

    tau    = randi([0,tmax],1); % Randomly timing offset
    
    cfo    = 0.000000463;           % Normalized CFO
    A      = exp(1j*2*pi*cfo*(0:length(Txdata)-1)).';   % Multiplicative interference
  
    y      = awgn(PChannel(hh,Txdata,Nw,tau,A), SNR(ii), 'measured');     % Received

    temp0  = reshape([real(y),imag(y)].', [], 1);  
    x_test(:,:,jj) = temp0; 
    Label (jj) = tau;

end
filenameM = sprintf('SNR[%d]dBx_test',SNR(ii));
save(filenameM,'x_test','Label');
toc
clear x_test;clear Label;
end

clear all








