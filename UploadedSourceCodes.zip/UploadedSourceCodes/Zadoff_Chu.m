

%************************************************************************%
%**   mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm                ***%
%**   Copyright (c) XiHua University. All rights reserved.            ***%
%**   Purpose:                                                        ***%
%**   Create by Chaojin Qing                                          ***%
%**   2017-6-15                                                       ***%
%**   Edition 0.1                                                     ***%
%**   Security level [Private]                                        ***%
%************************************************************************%
function out = Zadoff_Chu(len_seq)
% clear;
% clc
% close all;                                    
% len_seq = 2048;
N = len_seq;
M = 1;
q = 0;
k=1:1:N;   %k��1��32�����Ϊ1


temp = mod(len_seq,2); %tempΪlen_seq��ȡ��
if  temp==0
    out = exp(1i*2*pi*M/N*(k.^2/2+q.*k)).';%e^-j*,ģֵ��ȣ���Ϊ1
else
    out = exp(1i*2*pi*M/N*(k.*(k+1)./2+q.*k)).';
end
end











