
function Out = TxdataGen(N, Ng, Nc)

A = Zadoff_Chu(Nc); 
temp0 = A;      % training sequence
preamble = [temp0(end-Ng+1:end); temp0];   

temp1st = sqrt(N)*ifft(sqrt(0.5)*( randn(N,1) + 1j*randn(N,1)  ));
symbol_1st = [temp1st(end-Ng+1:end);temp1st;];

temp2nd = sqrt(N)*ifft(sqrt(0.5)*( randn(N,1) + 1j*randn(N,1)  ));
symbol_2rd = [temp2nd(end-Ng+1:end);temp2nd;];


TxData = [preamble;symbol_1st;symbol_2rd;];

Out = TxData;



