import h5py
import numpy as np
from keras.utils.np_utils import to_categorical
from keras.optimizers import adam_v2
from keras.models import load_model
from scipy import io
import keras.backend as K
import tensorflow as tf
import matplotlib.pyplot as plt

channel = 1     #
SNRdB = np.linspace(0, 12, 7).astype('int')    #
Ncp = h5py.File("test_para.mat")['Lc'][:].astype('int')
L = h5py.File("test_para.mat")['L'][:].astype('int')
L = int(L[0,0]-1)
ISI_free = int(Ncp[0,0]-L)
ISIfree_mid = L + np.round(ISI_free/2).astype('int')

def TSEP(y_true,y_pred):
    tau_est = tf.argmax(y_pred, axis=-1)
    tau = tf.argmax(y_true, axis=-1)+Ncp-ISIfree_mid
    delt_tau = tau-tau_est
    case1 = tf.greater_equal(delt_tau, 0)
    case2 = tf.less_equal(delt_tau, Ncp-L)
    return 1-K.mean(K.equal(case1, case2))

filepath = "./CNNModelWeightsdata.bestV7.hdf5"
model = load_model(filepath, compile=False)
model.compile(loss='categorical_crossentropy',
              optimizer=adam_v2.Adam(),
              metrics=[TSEP])
Pr = np.zeros((len(SNRdB), 1)).astype('float64')

for kk in range(len(SNRdB)):
    filenames = "SNR[%d]dBx_test.mat" % (SNRdB[kk])   #
    xd_input = h5py.File(filenames)['x_test'][:].astype('float64')
    training_samples, channel, Len = xd_input.shape
    xd_input = xd_input.reshape(training_samples, Len, channel).astype('float64')
    y_output = h5py.File(filenames)['Label'][:]
    num_labels = int(np.max(y_output)+int(Ncp[0,0])+1)
    y_output = to_categorical(y_output+ISIfree_mid, num_labels)
    y_evl = model.evaluate(xd_input, y_output, verbose=1, batch_size=10000)
    Pr[kk] = np.array(y_evl[1]).astype('float64')
    print('SNR%ddB' % SNRdB[kk])
    for i in range(0, len(model.metrics_names)):
        print(str(model.metrics_names[i]) + " = " + str(y_evl[i]))

filenames = 'Pr_%ddB_to_%ddB_%d.mat' % (SNRdB[0], SNRdB[kk], L)
io.savemat(filenames, {'Pr_ets': Pr})
x = SNRdB
plt.axes(yscale='log')
plt.plot(x,Pr,label='1dCNN_OFDM_TS', marker="o", markersize=8)
plt.xlabel('SNR (dB)')
plt.ylabel('Timing error probability of timing synchronization')
plt.show()