import h5py
import numpy as np
from keras.layers import Dense, Dropout, Input,BatchNormalization,Activation
from keras.layers import Conv1D,MaxPooling1D,Flatten, AveragePooling1D,Conv2D,LeakyReLU
from keras.models import Model,load_model
from keras.layers.merge import concatenate
from tensorflow.keras.initializers import glorot_normal
from keras.utils.np_utils import to_categorical
from keras.utils.vis_utils import plot_model
from keras.callbacks import ModelCheckpoint, LearningRateScheduler, ReduceLROnPlateau,EarlyStopping
from keras.optimizers import adam_v2
import keras.backend as K
import math
import tensorflow as tf
from keras import callbacks
from scipy import io
import random
seed = 30
tf.random.set_seed(seed)
#
XD_train = h5py.File("train_data.mat")['Datatrain'][:]
Y_train = h5py.File("train_label.mat")['Label'][:]
training_samples, channel, Len = XD_train.shape
xd_train = XD_train.reshape(training_samples, Len, channel).astype('float64')
N = h5py.File("Net_para.mat")['Nc'][:].astype('int')
Ncp = h5py.File("Net_para.mat")['Lc'][:].astype('int')
L = h5py.File("Net_para.mat")['L'][:].astype('int')
L = L[0,0]-1
ISI_free = int(Ncp[0,0]-L)
ISIfree_mid = L + np.round(ISI_free/2).astype('int')
batch_size = 64
iter_nums = 100
# label pre-coded
num_labels = int(np.max(Y_train)+Ncp+1)
y_train = to_categorical(Y_train+ISIfree_mid, num_classes=num_labels)
#
input_shape = (Len, channel)
Kener1 = int(2*N[0,0]+1)
Kener2 = int(np.floor(Ncp[0,0]/2)+1)
Kener3 = int(np.floor(Ncp[0,0]/2)+1)
filter1 = 4
filter2 = 4
filter3 = 2

def TSEP(y_true,y_pred):
    tau_est = tf.argmax(y_pred, axis=-1)
    tau = tf.argmax(y_true, axis=-1)+Ncp-ISIfree_mid
    delt_tau = tau-tau_est
    case1 = tf.greater_equal(delt_tau, 0)
    case2 = tf.less_equal(delt_tau, Ncp-L)
    return 1-K.mean(K.equal(case1, case2))

# def scheduler(epoch):
#     if epoch<15:
#           lr1 = 1e-3
#     elif epoch>=15:
#         lr1 = 2e-4
#     lr = lr1
#     return lr

# 1-D CNN-based TS network
inputs = Input(shape=input_shape)
y = inputs
y = Conv1D(filters=filter1,
           kernel_size=Kener1, kernel_initializer=glorot_normal(seed=seed),
           padding='valid',
           activation='relu',
           strides=2)(y)
y = Conv1D(filters=filter2,
           kernel_size=Kener2, kernel_initializer=glorot_normal(seed=seed),
           padding='same',
           activation='relu',
           strides=1)(y)
y = Conv1D(filters=filter3,
           kernel_size=Kener3, kernel_initializer=glorot_normal(seed=seed),
           padding='same',
           activation='relu',
           strides=1)(y)
y = AveragePooling1D()(y)
y = Flatten()(y)
y = Dense(num_labels, activation='tanh', kernel_initializer=glorot_normal(seed=seed))(y)
outputs = Dense(num_labels, activation='softmax',kernel_initializer=glorot_normal(seed=seed))(y)
# API functional
model = Model(inputs, outputs)
model.compile(loss='categorical_crossentropy',
              optimizer=adam_v2.Adam(),
              metrics=['accuracy', TSEP])

class LossHistory(callbacks.Callback):
    def on_train_begin(self, logs={}):
        self.losses_train = []
        self.losses_val = []
    def on_batch_end(self, batch, logs={}):
        self.losses_train.append(logs.get('TSEP'))
        self.losses_val.append(logs.get('loss'))

#
plot_model(model, to_file='FCNN-based TS network.png', show_shapes=True)
#
model.summary()
filepath = "./CNNModelWeightsdata.bestV7.hdf5"

# checkpoint = ModelCheckpoint(filepath, save_best_only=True, save_weights_only=False, mode='max', monitor="val_accuracy", verbose=1)
checkpoint = ModelCheckpoint(filepath, save_best_only=True, save_weights_only=False, mode='max', monitor="val_accuracy", verbose=1)
# reduce_lr = tf.keras.callbacks.LearningRateScheduler(scheduler,verbose=0)
el_stopping = EarlyStopping(monitor='val_accuracy',patience=5, mode='max',restore_best_weights=True)
reduce_lr = ReduceLROnPlateau(monitor='val_accuracy',mode='max',factor=0.2,min_lr=1e-4, patience=3, verbose=1)
# Fit the model
history = LossHistory()
model.fit(xd_train, y_train,
          validation_split=0.2,
          callbacks=[checkpoint,history,reduce_lr,el_stopping],
          epochs=iter_nums, batch_size=batch_size, verbose=2,shuffle=False)

loss_history_train = np.array(history.losses_train)
filenames1 = 'loss_TSEP.mat'  # % (SNRdB[0], SNRdB[kk])
io.savemat(filenames1, {'loss_TSEP': loss_history_train})
loss_history_valid = np.array(history.losses_val)
filenames2 = 'loss_file.mat'  # % (SNRdB[0], SNRdB[kk])
io.savemat(filenames2, {'loss_file': loss_history_valid})